# Smooth-Scroll-Effect
This is a JS app that has the navbar control the scrolling feature in other to quickly move to the details of the selected navbar item. This is mostly used on single page websites
